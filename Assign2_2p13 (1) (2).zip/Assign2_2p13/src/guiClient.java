import java.awt.*;
import java.net.*;
import java.io.*;
import java.util.Objects;
import java.util.Scanner;
import javax.swing.*;




/*
 * Name: Jerome Uwaneme
 * Student Number 7141270
 * Course COSC 2P13
 * Date 04/04/17
 *
 *
 *
 * To start a game first run the ConnectFourServer  class then depending on whether you would like to test with a Gui or terminal
 *
 * Gui --------------
 * You may need to allow multiple instances of the guiClient on  intellij  to test
 * Run 2 instances of the guiClient
 * Follow instruction provided to each player
 *
 *
 * Terminal-----------
 * please type nc localhost 1704  on mobaxterm
 * and then instruction will be provided
 *
 * Terminal vs Terminal, Gui vs Gui and Terminal vs Gui is possible
 *
 * Terminal v Terminal
 * Type nc localhost 1704 on 2 instances of a terminal
 *
 * Gui v Gui
 * Run 2  Gui instances
 *
 * Gui vs Terminal
 * please type nc localhost 1704  on mobaxterm
 * Run a guiClient instance
 *
 *
 *
 *
 *
 * */




//Gui class will require multiple instances to test GUI vs GUI gameplay
//Please when running Gui scroll to the very bottom to view updated game board
public class guiClient {

    public static void main(String[] args) {
        String hostName="localhost";
        int portNumber=1704;
        String serverMessage ;



        try (
                //Set up connection to server
                Socket conn=new Socket(hostName, portNumber);
                PrintWriter sockOut=new PrintWriter(conn.getOutputStream(),true);
                BufferedReader sockIn=new BufferedReader(new InputStreamReader(conn.getInputStream()));


        ){//Creating  the JFrame


            JFrame frame = new JFrame("Connect Four");//Gui page
            // Remove default button association
            frame.getRootPane().setDefaultButton(null);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//Exit application when closed
            JTextArea textArea = new JTextArea();//Contain Text
            JScrollPane scrollPane = new JScrollPane(textArea);// Scroll pane for text area
            textArea.setEditable(false);//Prevent user editing instructions
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
            //Always displays vertical scroll bar

            frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
            frame.setSize(800, 700);
            frame.setVisible(true);

            JTextField inputField = new JTextField();
            JButton sendButton = new JButton("Send Move");
            JPanel inputPanel = new JPanel();

            //Button and input position
            inputPanel.setLayout(new BorderLayout());
            inputPanel.add(inputField, BorderLayout.CENTER);
            inputPanel.add(sendButton, BorderLayout.EAST);
            frame.getContentPane().add(inputPanel, BorderLayout.SOUTH);
            //Input and button not initially editable
            inputField.setEditable(false);
            sendButton.setEnabled(false);


            //Onclick sends the user move to be processed by server
            sendButton.addActionListener(event->{
                sockOut.println(inputField.getText().trim());
                inputField.setText(null);
                inputField.setEditable(false); // Disable the input field
                sendButton.setEnabled(false); // Disable the send button
            });

            //Parsing loop

            while ((serverMessage = sockIn.readLine()) != null) {//While server is still sending messages
                textArea.append(serverMessage + "\n");//Print message to textArea

                if (serverMessage.equals("Player2 wins") || serverMessage.equals("Player1 wins")) {//Break on wind conditon
                    break;
                }

                if (serverMessage.contains("Please enter your move:")) {//If server sends this allow user input into input field and allow button
                    inputField.setEditable(true);
                    sendButton.setEnabled(true);
                }
            }

            // After the loop
            inputField.setEditable(false);
            sendButton.setEnabled(false);






        } catch (UnknownHostException e) {
            System.out.println("I think there's a problem with the host name.");
        } catch (IOException e) {
            System.out.println("Had an IO error for the connection.");
        }
    }

}

