import java.net.*;
import java.io.*;




/*
 * Name: Jerome Uwaneme
 * Student Number 7141270
 * Course COSC 2P13
 * Date 04/04/17
 *
 *
 *
 * To start a game first run the ConnectFourServer  class then depending on whether you would like to test with a Gui or terminal
 *
 * Gui --------------
 * You may need to allow multiple instances of the guiClient on  intellij  to test
 * Run 2 instances of the guiClient
 * Follow instruction provided to each player
 *
 *
 * Terminal-----------
 * please type nc localhost 1704  on mobaxterm
 * and then instruction will be provided
 *
 * Terminal vs Terminal, Gui vs Gui and Terminal vs Gui is possible
 *
 * Terminal v Terminal
 * Type nc localhost 1704 on 2 instances of a terminal
 *
 * Gui v Gui
 * Run 2  Gui instances
 *
 * Gui vs Terminal
 * please type nc localhost 1704  on mobaxterm
 * Run a guiClient instance
 *

 * */


/*A game starts when 2 clients connect to server
*
* This class runs a game instance for those clients terminal or gui
* */




public class PlayersThread extends Thread{
    private final Socket client1;
    private final Socket client2;
    ConnectFourGame game ;
    boolean isPlayer1Turn = true;
    boolean isPlayer2Turn = false;

    boolean winCondition  = false;


    public PlayersThread(Socket c1, Socket c2) {
        client1=c1;
        client2=c2;
    }


    public void run() {
        game = new ConnectFourGame();

        try (
                PrintWriter out1 = new PrintWriter(client1.getOutputStream(), true);
                PrintWriter out2 = new PrintWriter(client2.getOutputStream(), true);
                BufferedReader in1 = new BufferedReader(new InputStreamReader(client1.getInputStream()));
                BufferedReader in2 = new BufferedReader(new InputStreamReader(client2.getInputStream()))
        ) {
            //Send game Board and Instruction to players
            out1.println(game.visualizeCharArray(game.board));
            out1.println("Welcome to ConnectFour player 1. "+"\n"
                    +" Above is a board that represents the connect four grid both players can see. zero's representing empty spaces " +"\n"
                    + "Your piece on the board is X. "+"\n"
                    +"You can make a move by entering the  number of the row you wish to play into "
                    +"Enter zero or any other character to quit the game "
            );
            out2.println(game.visualizeCharArray(game.board));
            out2.println("Welcome to ConnectFour player 2."+"\n"
                    +" Above is a board that represents the connect four grid both players can see. zero's representing empty spaces "+"\n"
                    +"Your piece on the board is Y. "+"\n"
                    +"You can make a move by entering the  number of the row you wish to play into "
                    + "Enter zero or any other character to quit the game "
            );

            //Game loop
            while(true){
                // Player 1's turn
                if(isPlayer1Turn){
                    out1.println("Player 1's turn. Please enter your move:");
                    out1.println(game.visualizeCharArray(game.board));
                    String player1Move = in1.readLine();
                    if(player1Move.equals("0")){
                        break;
                    }
                    if(player1Move.equals(null)||player1Move.equals("")){
                        out1.println("Cannot be null");
                        continue;
                    }
                    else{
                        int col1 = Integer.parseInt(player1Move)-1;
                        if(game.isFull(col1)){
                            out1.println("Invalid move, column full");
                            //Updates board with user move and send move to client
                        }else{
                            game.drop(col1,'X');
                            out1.println(game.visualizeCharArray(game.board));
                            out2.println(game.visualizeCharArray(game.board));
                            isPlayer1Turn = false;
                            isPlayer2Turn = true;
                        }
                    }
                }
                //CHECK FOR WIN

                //Player 1 win
                if(game.verticalCheck('X')||game.diagonalCheck('X')||game.horizontalCheck('X')){
                    out1.println("Player1 wins");
                    out2.println("Player1 wins");
                    break;
                }
                //Player 2 win
                if(game.verticalCheck('Y')||game.diagonalCheck('Y')||game.horizontalCheck('Y')){
                    out1.println("Player2 wins");
                    out2.println("Player2 wins");
                    break;
                }


                //Player 2's turn

                if(isPlayer2Turn){
                    out2.println("Player 2's turn. Please enter your move:");
                    out2.println(game.visualizeCharArray(game.board));
                    String player2Move = in2.readLine();
                    if(player2Move.equals("0")){
                        break;
                    }
                    if(player2Move.equals(null)||player2Move.equals("")){
                        out2.println("Cannot be null");
                        continue;
                    }

                    else{
                        int col2 = Integer.parseInt(player2Move)-1;
                        if(game.isFull(col2)){
                            out2.println("Invalid move, column full");
                        }else{
                            game.drop(col2,'Y');
                            out2.println(game.visualizeCharArray(game.board));
                            out1.println(game.visualizeCharArray(game.board));
                            isPlayer2Turn = false;
                            isPlayer1Turn = true;
                        }
                    }
                }
                //CHECK FOR WIN
                if(game.verticalCheck('X')||game.diagonalCheck('X')||game.horizontalCheck('X')){
                    out1.println("Player1 wins");
                    out2.println("Player1 wins");
                    break;
                }
                if(game.verticalCheck('Y')||game.diagonalCheck('Y')||game.horizontalCheck('Y')){
                    out1.println("Player2 wins");
                    out2.println("Player2 wins");
                    break;
                }
            }

        } catch (IOException e) {
            System.out.println("Ah nertz.");
        }
    }
}
