public class ConnectFourGame {
    public final char[][] board;
    private final char Player1='X';

    private final char Player2 ='Y';

    //This class handles game logic  implements player moves and checks for win and full column conditions


    /*
     * Name: Jerome Uwaneme
     * Student Number 7141270
     * Course COSC 2P13
     * Date 04/04/17
     *
     *
     *
     * To start a game first run the ConnectFourServer  class then depending on whether you would like to test with a Gui or terminal
     *
     * Gui --------------
     * You may need to allow multiple instances of the guiClient on  intellij  to test
     * Run 2 instances of the guiClient
     * Follow instruction provided to each player
     *
     *
     * Terminal-----------
     * please type nc localhost 1704  on mobaxterm
     * and then instruction will be provided
     *
     * Terminal vs Terminal, Gui vs Gui and Terminal vs Gui is possible
     *
     * Terminal v Terminal
     * Type nc localhost 1704 on 2 instances of a terminal
     *
     * Gui v Gui
     * Run 2  Gui instances
     *
     * Gui vs Terminal
     * please type nc localhost 1704  on mobaxterm
     * Run a guiClient instance
     *
     *
     *
     *
     *
     * */


    //GAME LOGIC
    public ConnectFourGame() {
        board = new char[6][7];    // 6 rows, 7 columns
        initializeBoard();
    }


    //Prints the connect4 board
    public  String visualizeCharArray(char[][] array) {
        StringBuilder sb = new StringBuilder();
        for (char[] chars : array) {
            for (char aChar : chars) {
                sb.append(aChar).append(" ");
            }
            sb.append("\n"); // Move to the next line after printing each row
        }
        return sb.toString();
    }

    //Creates the board
    private void initializeBoard() {
        for (int row = 0; row < 6; row++) {
            for (int col = 0; col < 7; col++) {
                board[row][col] = '0';
            }
        }
    }

    //A player dropping their piece into the board
    public void drop(int col, char Player) {
        int cur_row = board.length - 1;
        // Start from the bottom and move upwards until an empty cell is found
        while (cur_row >= 0 && board[cur_row][col] != '0') {
            cur_row--;
        }
        // Place the player's piece in the first empty cell found
        if (cur_row >= 0) {
            board[cur_row][col] = Player;
        }
    }

    public boolean isFull(int col) {
        return board[0][col] != '0'; // Column is full
    }





    public boolean verticalCheck(char player) {
        // Initialize win as false
        boolean win = false;

        // Iterate through each column of the board
        for (int col = 0; col < 7; col++) {
            // Iterate through each row of the column
            for (int row = 0; row < 6; row++) {
                // Check for vertical win downwards
                if (row + 3 < 6 && board[row][col] == player && board[row + 1][col] == player && board[row + 2][col] == player && board[row + 3][col] == player) {
                    win = true; // Vertical win downwards
                    break; // Exit the loop once a win is found
                }
                // Check for vertical win upwards
                if (row - 3 >= 0 && board[row][col] == player && board[row - 1][col] == player && board[row - 2][col] == player && board[row - 3][col] == player) {
                    win = true;
                    break;
                }
            }
            //exits loop on win
            if (win) {
                break;
            }
        }
        // Return the value of win
        return win;
    }


    public boolean horizontalCheck(char player) {
        // Iterate through each cell of the board
        for (int row = 0; row < 6; row++) {
            for (int col = 0; col < 7; col++) {
                // Check for horizontal win to the right
                if (col + 3 < 7 && board[row][col] == player && board[row][col + 1] == player && board[row][col + 2] == player && board[row][col + 3] == player) {
                    return true; // Horizontal win to the right
                }

                // Check for horizontal win to the left
                if (col - 3 >= 0 && board[row][col] == player && board[row][col - 1] == player && board[row][col - 2] == player && board[row][col - 3] == player) {
                    return true; // Horizontal win to the left
                }
            }
        }
        // No horizontal win found
        return false;
    }

    // Method to check for a diagonal win
    public boolean diagonalCheck(char player) {

        //Top left to bottom right
        for (int row = 0; row < board.length - 3; row++) {
            for (int col = 0; col < board[row].length - 3; col++) {
                if (board[row][col] == player && board[row+1][col+1] == player && board[row+2][col+2] == player && board[row+3][col+3] == player) {
                    return true;
                }
            }
        }

        //Bottom left to top right
        for (int row = 3; row < board.length; row++) {
            for (int col = 0; col < board[row].length - 3; col++) {
                if (board[row][col] == player && board[row-1][col+1] == player && board[row-2][col+2] == player && board[row-3][col+3] == player) {
                    return true;
                }
            }
        }
        //Top right to Bottom left
        for (int row = 0; row < board.length - 3; row++) {
            for (int col = 3; col < board[row].length; col++) {
                if (board[row][col] == player && board[row+1][col-1] == player && board[row+2][col-2] == player && board[row+3][col-3] == player) {
                    return true;
                }
            }
        }
        //Bottom right to top left
        for (int row = 3; row < board.length; row++) {
            for (int col = 3; col < board[row].length; col++) {
                if (board[row][col] == player && board[row-1][col-1] == player && board[row-2][col-2] == player && board[row-3][col-3] == player) {
                    return true;
                }
            }
        }
        //No diagonal win
        return false;
    }


    public static void main(String[] args) {
        ConnectFourGame C4 = new ConnectFourGame();

    }

}
