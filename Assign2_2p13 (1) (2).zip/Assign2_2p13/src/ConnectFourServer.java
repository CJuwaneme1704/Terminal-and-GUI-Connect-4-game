import java.net.*;
import java.io.*;
import java.util.*;



/*
 * Name: Jerome Uwaneme
 * Student Number 7141270
 * Course COSC 2P13
 * Date 04/04/17
 *
 *
 *
 * To start a game first run the ConnectFourServer  class then depending on whether you would like to test with a Gui or terminal
 *
 * Gui --------------
 * You may need to allow multiple instances of the guiClient on  intellij  to test
 * Run 2 instances of the guiClient
 * Follow instruction provided to each player
 *
 *
 * Terminal-----------
 * please type nc localhost 1704  on mobaxterm
 * and then instruction will be provided
 *
 * Terminal vs Terminal, Gui vs Gui and Terminal vs Gui is possible
 *
 * Terminal v Terminal
 * Type nc localhost 1704 on 2 instances of a terminal
 *
 * Gui v Gui
 * Run 2  Gui instances
 *
 * Gui vs Terminal
 * please type nc localhost 1704  on mobaxterm
 * Run a guiClient instance
 *
 *
 *
 *
 *
 * */



//Server runs  threads that serve as game masters for the 2 player clients
//2 clients must connect to server before a game can begin
public class ConnectFourServer {
    // Port number for the server
    public static int port = 1704;


    // ArrayList to hold connected players
    static ArrayList<Socket>players= new ArrayList<>();


    public static void main(String[] args) {
        // Print message indicating that the server has started
        System.out.println("Server started. Waiting for players...");

        try (
                ServerSocket serverSocket = new ServerSocket(port);
                // Create a ServerSocket to listen for incoming connections on the specified port
        ) {
            while (true) {
                // Accept incoming connection from a player
                Socket player = serverSocket.accept();
                // Print message indicating a new player has connected
                System.out.println("New player connected");
                // If there are no players currently connected, add the new player to the list
                if(players.isEmpty()){
                    players.add(player);
                }else {
                    // If there is already a player connected, pair the new player with the existing one
                    Socket otherplayer = players.get(0);
                    new PlayersThread(otherplayer,player).start();
                    players.clear();
                }
            }
        } catch (IOException e) {
            System.out.println("Exception caught when trying to listen on port " + port + " or listening for a connection");
            System.out.println(e.getMessage());
        }
    }
}

